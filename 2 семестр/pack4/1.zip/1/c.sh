gcc -c -fPIC integerset.c
gcc -shared -o integerset.so integerset.o