#include <stdio.h>
#include "modular.h"

int MOD = 1000000007;

int pnorm(int a){
	return (a % MOD < 0) ? MOD + (a % MOD) : a % MOD;
}

int padd(int a, int b){
	long long x = (long long) a + (long long) b;
	return (x % MOD < 0) ? MOD + (x % MOD) : x % MOD;
}

int psub(int a, int b){
	long long x = (long long) a - (long long) b;
	return (x % MOD < 0) ? MOD + (x % MOD) : x % MOD;
}

int pmul(int a, int b){
	long long x = (long long) a * (long long) b;
	return (x % MOD < 0) ? MOD + (x % MOD) : x % MOD;
}

void ext_euclid(long long a, long long b, long long *x, long long *y, long long *d){
	long long q, r, x1, y1, x2, y2;
	if (b == 0) {
		*d = a;
		*x = 1;
		*y = 0;
		return;
	}
	x1 = 0;
	x2 = 1;
	y1 = 1;
	y2 = 0;
	while (b > 0) {
		q = a / b;
		r = a - q * b;	//новый остаток
		*x = x2 - q * x1;
		*y = y2 - q * y1;
		a = b;
		b = r;
		x2 = x1;
		x1 = *x;
		y2 = y1;
		y1 = *y;
	}
	*d = a, *x = x2, *y = y2;
}


long long inverse(long long a, long long m){
	long long d, x, y;
	ext_euclid(a, m, &x, &y, &d);
	if (d == 1){
		return x;
	}
	return 0;
}

int pdiv(int a, int b){
	long long x = inverse(b, MOD);
	long long res = a * x;
	return (res % MOD < 0) ? MOD + (res % MOD) : res % MOD;
}
