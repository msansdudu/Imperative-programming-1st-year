#include "modular.h"
#include <assert.h>

int main(){
	MOD = 13;
	assert(pnorm(10) == 10);
	assert(pnorm(-5) == 8);
	assert(pnorm(132) == 2);
	
	MOD = 7;
	assert(padd(5, 5) == 3);
	assert(padd(3, 4) == 0);
	assert(padd(2, 2) == 4);
	
	assert(psub(5, 4) == 1);
	assert(psub(3, 6) == 4);
	
	MOD = 13;
	int x = pmul(padd(7, psub(2, 3)), 5);
	assert(x == 4);
	int y = pdiv(7, x);
	assert(pmul(x, y) == 7);
	assert(pmul(0, 3) == 0);
	assert(pmul(10, 2) == 7);
	
	MOD = 1000000007;
	assert(pmul(50968400, 1962000) == 100000);
	assert(pdiv(50968400, 1962000) == 177777805);
	return 0;
}
